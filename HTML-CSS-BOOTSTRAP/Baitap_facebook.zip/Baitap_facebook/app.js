var form = document.querySelector("form");
var email = document.querySelector("input[name=email]");
var confirm_email = document.querySelector(
  "input[name=confirm_email]"
);

form.addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Welcome to Facebook");
});

function onchange() {
  if (confirm_email.value === email.value) {
    confirm_email.setCustomValidity("");
  } else {
    confirm_email.setCustomValidity("Email not match");
  }
}
